# my_config.py

is_training =  0

scale = 1000
total_explore  = 3*scale**2 #100000.0 #300000.0 
max_eps = 10*scale #3000
max_steps_eps = 4*scale #100000 # 2000
epsilon_start  = 1.0
port = 3101
