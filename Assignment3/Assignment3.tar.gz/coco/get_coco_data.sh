wget "http://deepspark.snu.ac.kr/pubs/coco_data.tar.gz"
tar -xzvf coco_data.tar.gz
rm coco_data.tar.gz
